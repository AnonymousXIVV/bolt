import { cn } from '@/lib/utils';
import { Play } from 'lucide-react';
import { useState } from 'react';
import { Button } from '../ui/button';

interface VideoPlayerProps {
  previewOnly?: boolean;
  thumbnailUrl: string;
  title: string;
  className?: string;
}

export function VideoPlayer({
  previewOnly = false,
  thumbnailUrl,
  title,
  className,
}: VideoPlayerProps) {
  const [isPlaying, setIsPlaying] = useState(false);

  return (
    <div
      className={cn(
        'relative aspect-video w-full overflow-hidden rounded-lg bg-gray-900',
        className
      )}
    >
      {!isPlaying && (
        <>
          <img
            src={thumbnailUrl}
            alt={title}
            className="h-full w-full object-cover"
          />
          <div className="absolute inset-0 flex items-center justify-center bg-black/40">
            <Button
              onClick={() => setIsPlaying(true)}
              className="flex h-16 w-16 items-center justify-center rounded-full bg-white/90 text-gray-900 hover:bg-white"
            >
              <Play className="h-8 w-8" />
            </Button>
          </div>
          {previewOnly && (
            <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 to-transparent p-4 text-white">
              <p className="text-sm font-medium">Preview Only</p>
              <p className="text-xs opacity-80">
                Subscribe to watch the full stream
              </p>
            </div>
          )}
        </>
      )}
      {isPlaying && (
        <div className="flex h-full items-center justify-center">
          <p className="text-white opacity-60">Stream player placeholder</p>
        </div>
      )}
    </div>
  );
}