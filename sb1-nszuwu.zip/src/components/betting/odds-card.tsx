import { cn } from '@/lib/utils';
import { Button } from '../ui/button';

interface OddsCardProps {
  team1: string;
  team2: string;
  odds1: number;
  odds2: number;
  className?: string;
}

export function OddsCard({
  team1,
  team2,
  odds1,
  odds2,
  className,
}: OddsCardProps) {
  return (
    <div
      className={cn(
        'rounded-lg border bg-white p-4 shadow-sm',
        className
      )}
    >
      <div className="mb-4 flex items-center justify-between">
        <h3 className="font-semibold">{team1} vs {team2}</h3>
        <span className="text-sm text-gray-500">Live</span>
      </div>
      
      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <p className="text-sm font-medium">{team1}</p>
          <Button
            variant="outline"
            className="w-full justify-between"
          >
            <span>Win</span>
            <span className="font-semibold">{odds1.toFixed(2)}</span>
          </Button>
        </div>
        
        <div className="space-y-2">
          <p className="text-sm font-medium">{team2}</p>
          <Button
            variant="outline"
            className="w-full justify-between"
          >
            <span>Win</span>
            <span className="font-semibold">{odds2.toFixed(2)}</span>
          </Button>
        </div>
      </div>
    </div>
  );
}