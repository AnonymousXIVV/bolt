import { VideoPlayer } from '@/components/stream/video-player';
import { OddsCard } from '@/components/betting/odds-card';

export function HomePage() {
  return (
    <div className="min-h-screen bg-gray-50">
      <main className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
        <div className="grid gap-8 lg:grid-cols-3">
          <div className="lg:col-span-2">
            <h1 className="mb-4 text-2xl font-bold">Featured Match</h1>
            <VideoPlayer
              thumbnailUrl="https://images.unsplash.com/photo-1574629810360-7efbbe195018?auto=format&fit=crop&q=80"
              title="Champions League Final"
              previewOnly={true}
            />
          </div>
          
          <div>
            <h2 className="mb-4 text-xl font-semibold">Live Betting</h2>
            <div className="space-y-4">
              <OddsCard
                team1="Manchester City"
                team2="Real Madrid"
                odds1={1.95}
                odds2={2.15}
              />
              <OddsCard
                team1="Bayern Munich"
                team2="PSG"
                odds1={1.85}
                odds2={2.25}
              />
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}