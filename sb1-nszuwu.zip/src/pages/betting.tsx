import { OddsCard } from '@/components/betting/odds-card';

export function BettingPage() {
  const matches = [
    {
      id: 1,
      team1: "Manchester City",
      team2: "Real Madrid",
      odds1: 1.95,
      odds2: 2.15,
    },
    {
      id: 2,
      team1: "Bayern Munich",
      team2: "PSG",
      odds1: 1.85,
      odds2: 2.25,
    },
    {
      id: 3,
      team1: "Liverpool",
      team2: "Arsenal",
      odds1: 2.10,
      odds2: 1.95,
    },
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      <main className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
        <h1 className="mb-6 text-2xl font-bold">Live Betting</h1>
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {matches.map((match) => (
            <OddsCard
              key={match.id}
              team1={match.team1}
              team2={match.team2}
              odds1={match.odds1}
              odds2={match.odds2}
            />
          ))}
        </div>
      </main>
    </div>
  );
}