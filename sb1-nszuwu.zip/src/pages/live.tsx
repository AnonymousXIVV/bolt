import { VideoPlayer } from '@/components/stream/video-player';

export function LivePage() {
  const liveMatches = [
    {
      id: 1,
      title: "Champions League Final",
      thumbnail: "https://images.unsplash.com/photo-1574629810360-7efbbe195018?auto=format&fit=crop&q=80",
    },
    {
      id: 2,
      title: "Premier League: Liverpool vs Arsenal",
      thumbnail: "https://images.unsplash.com/photo-1508098682722-e99c43a406b2?auto=format&fit=crop&q=80",
    },
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      <main className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
        <h1 className="mb-6 text-2xl font-bold">Live Games</h1>
        <div className="grid gap-6 md:grid-cols-2">
          {liveMatches.map((match) => (
            <VideoPlayer
              key={match.id}
              title={match.title}
              thumbnailUrl={match.thumbnail}
              previewOnly={true}
            />
          ))}
        </div>
      </main>
    </div>
  );
}