import { Calendar } from 'lucide-react';

interface ScheduledMatch {
  id: number;
  team1: string;
  team2: string;
  date: string;
  time: string;
  competition: string;
}

export function SchedulePage() {
  const scheduledMatches: ScheduledMatch[] = [
    {
      id: 1,
      team1: "Manchester United",
      team2: "Chelsea",
      date: "2024-03-20",
      time: "20:45",
      competition: "Premier League",
    },
    {
      id: 2,
      team1: "Barcelona",
      team2: "Atletico Madrid",
      date: "2024-03-21",
      time: "21:00",
      competition: "La Liga",
    },
    {
      id: 3,
      team1: "Juventus",
      team2: "Inter Milan",
      date: "2024-03-22",
      time: "20:45",
      competition: "Serie A",
    },
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      <main className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
        <h1 className="mb-6 text-2xl font-bold">Upcoming Matches</h1>
        <div className="space-y-4">
          {scheduledMatches.map((match) => (
            <div
              key={match.id}
              className="flex items-center rounded-lg border bg-white p-4 shadow-sm"
            >
              <Calendar className="mr-4 h-6 w-6 text-gray-400" />
              <div className="flex-1">
                <div className="flex items-center justify-between">
                  <h3 className="font-semibold">
                    {match.team1} vs {match.team2}
                  </h3>
                  <span className="text-sm text-gray-500">{match.competition}</span>
                </div>
                <p className="mt-1 text-sm text-gray-600">
                  {new Date(match.date).toLocaleDateString()} at {match.time}
                </p>
              </div>
            </div>
          ))}
        </div>
      </main>
    </div>
  );
}