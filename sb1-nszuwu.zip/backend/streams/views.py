from rest_framework import viewsets, permissions
from rest_framework.decorators import action
from rest_framework.response import Response
from .models import Stream, Subscription
from .serializers import StreamSerializer, SubscriptionSerializer

class StreamViewSet(viewsets.ModelViewSet):
    queryset = Stream.objects.all()
    serializer_class = StreamSerializer
    permission_classes = [permissions.IsAuthenticatedOrReadOnly]

    @action(detail=True, methods=['get'])
    def check_access(self, request, pk=None):
        stream = self.get_object()
        user = request.user
        
        if not user.is_authenticated:
            return Response({'has_access': False, 'reason': 'Not authenticated'})
            
        has_subscription = Subscription.objects.filter(
            user=user,
            is_active=True
        ).exists()
        
        return Response({
            'has_access': has_subscription,
            'reason': 'No active subscription' if not has_subscription else None
        })