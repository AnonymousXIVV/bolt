from rest_framework import viewsets, permissions
from rest_framework.decorators import action
from rest_framework.response import Response
from .models import Match, Odds, Bet
from .serializers import MatchSerializer, OddsSerializer, BetSerializer

class MatchViewSet(viewsets.ModelViewSet):
    queryset = Match.objects.all()
    serializer_class = MatchSerializer
    permission_classes = [permissions.IsAuthenticatedOrReadOnly]

    @action(detail=True, methods=['get'])
    def odds(self, request, pk=None):
        match = self.get_object()
        odds = Odds.objects.filter(match=match).order_by('-updated_at').first()
        serializer = OddsSerializer(odds)
        return Response(serializer.data)

class BetViewSet(viewsets.ModelViewSet):
    queryset = Bet.objects.all()
    serializer_class = BetSerializer
    permission_classes = [permissions.IsAuthenticated]

    def get_queryset(self):
        return Bet.objects.filter(user=self.request.user)